import { Component } from '@angular/core';
import * as XLSX from 'xlsx';
@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  name = 'Angular';
  onFileChange(ev) {
    let workBook = null;
    let jsonData = null;
    const reader = new FileReader();
    const file = ev.target.files[0];
    reader.onload = (event) => {
      const data = reader.result;
      workBook = XLSX.read(data, { type: 'binary' });
      jsonData = workBook.SheetNames.reduce((initial, name) => {
        const sheet = workBook.Sheets[name];
        initial[name] = XLSX.utils.sheet_to_json(sheet);
        return initial;
      }, {});
      this.calculateMeanEffortByTeam(jsonData);
      this.calculateEmployeeWithLowestEfficiency(jsonData);
    };
    reader.readAsBinaryString(file);
  }
  calculateMeanEffortByTeam(jsonData: any) {
    let efforts = {};
    let effortsChild = {};
    let sum = 0;
    let count = 0;
    let projectName = '';
    jsonData['All Projects'].forEach((data) => {
      if (projectName !== data['Project Name']) {
        projectName = data['Project Name'];
        effortsChild = {};
      }
      count++;
      if (effortsChild.hasOwnProperty(data['Team'])) {
        sum += parseFloat(data['Hours']);
      } else {
        sum = parseFloat(data['Hours']);
      }
      effortsChild[data['Team']] = (sum / count).toFixed(2);
      efforts[data['Project Name']] = effortsChild;
    });
    console.log(efforts);
  }
  calculateEmployeeWithLowestEfficiency(jsonData: any) {
    let ownersEffort = {};
    jsonData['All Projects'].forEach((data) => {
      let avgConfig = {};
      let ownerName = data['Owner'];
      if (ownersEffort.hasOwnProperty(ownerName)) {
        avgConfig = ownersEffort[ownerName];
        avgConfig['size'] += 1;
        avgConfig['sum'] += parseFloat(data['Hours']);
        avgConfig['avg'] = (avgConfig['sum'] / avgConfig['size']).toFixed(2);
        avgConfig = ownersEffort[ownerName];
      } else {
        avgConfig['size'] = 1;
        avgConfig['sum'] = parseFloat(data['Hours']);
        avgConfig['avg'] = (avgConfig['sum'] / avgConfig['size']).toFixed(2);
        ownersEffort[ownerName] = avgConfig;
      }
    });
    let sortable = [];
    for (var emp in ownersEffort) {
      let empObj = {};
      empObj['name'] = emp;
      empObj['avg'] = ownersEffort[emp].avg;
      sortable.push(empObj);
    }
    sortable.sort((a, b) => {
      return b.avg - a.avg;
    });
    sortable = sortable.filter((data, index) => {
      if (index < 5) {
        return data;
      }
    });
    console.log('ownersEffort::', sortable);
  }
}
